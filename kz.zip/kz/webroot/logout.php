<?php

setcookie("admin","");
header("Location: /ru/")
?>