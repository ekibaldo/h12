<?php
    namespace App\Controller;

    use App\Controller\AppController;

    class AdminController extends AppController
    {
    	public function index()
    	{
    		//$this->viewBuilder()->setLayout('hosp');
    	}
	
        public function layout()
        {

        }

    }