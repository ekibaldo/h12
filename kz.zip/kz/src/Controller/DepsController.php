<?php


    namespace App\Controller;

    use App\Controller\AppController;

    class DepsController extends AppController
    {
	    public function index()
	    {
	    	$this->viewBuilder()->setLayout('hosp');
	    }
    }




?>