<?php
namespace App\Controller;

use App\Controller\AppController;

class GovsymController extends AppController
{
  public function flag()
    {
        $this->viewBuilder()->setLayout('hosp');
    }
  public function emblem()
    {
        $this->viewBuilder()->setLayout('hosp');
    }
  public function anthem()
    {
        $this->viewBuilder()->setLayout('hosp');
    }
  public function information()
    {
        $this->viewBuilder()->setLayout('hosp');
    }
}
