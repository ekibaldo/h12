<?php
namespace App\Controller;

use App\Controller\AppController;

class AboutController extends AppController
{
  public function index()
    {
        $this->viewBuilder()->setLayout('hosp');
    }
	
  public function blog()
    {
        $this->viewBuilder()->setLayout('hosp');
    }	
	
  public function history()
    {
        $this->viewBuilder()->setLayout('hosp');
    }	
	
  public function structure()
    {
        $this->viewBuilder()->setLayout('hosp');
    }		

  public function administration()
    {
        $this->viewBuilder()->setLayout('hosp');
    }		
	
  public function laws()
    {
        $this->viewBuilder()->setLayout('hosp');
    }	
	
  public function awards()
    {
        $this->viewBuilder()->setLayout('hosp');
    }		

  public function reports()
    {
        $this->viewBuilder()->setLayout('hosp');
    }			
	
}   
