<?php

header("Location: dialog.php");

?>